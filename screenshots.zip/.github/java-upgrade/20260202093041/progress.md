# Upgrade Progress

  ### ✅ Generate Upgrade Plan
  - [[View Log]](logs\1.generatePlan.log)

  ### ✅ Confirm Upgrade Plan
  - [[View Log]](logs\2.confirmPlan.log)

  ### ❗ Setup Development Environment
  - [[View Log]](logs\3.setupEnvironment.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Uncommitted changes found, please stash, commit or discard them first. You'd better let the user to choose the action to take.
  </details>

  ### ✅ Setup Development Environment
  - [[View Log]](logs\4.setupEnvironment.log)

  ### ✅ PreCheck
  - [[View Log]](logs\5.precheck.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ✅ Precheck - Build project
    - [[View Log]](logs\5.1.precheck-buildProject.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    </details>
  
    ### ✅ Precheck - Validate CVEs
    - [[View Log]](logs\5.2.precheck-validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### CVE issues
    - Dependency `io.github.bonigarcia:webdrivermanager:5.7.0` has **1** known CVEs:
      - [CVE-2025-4641](https://github.com/advisories/GHSA-pwm3-776c-8q7q): BoniGarcia WebDriverManager Affected By Improper Restriction of XML External Entity Reference
        - **Severity**: **CRITICAL**
        - **Details**: Improper Restriction of XML External Entity Reference vulnerability in bonigarcia webdrivermanager on Windows, MacOS, Linux (XML parsing components modules) allows Data Serialization External Entities Blowup. This vulnerability is associated with program files src/main/java/io/github/bonigarcia/wdm/WebDriverManager.java.
          
          This issue affects webdrivermanager: from 1.0.0 before 6.1.0.
    </details>
  
    ### ✅ Precheck - Run tests
    - [[View Log]](logs\5.3.precheck-runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Test result
    | Total | Passed | Failed | Skipped | Errors |
    |-------|--------|--------|---------|--------|
    | 4 | 1 | 3 | 0 | 0 |
    </details>
  </details>

  ### ✅ Upgrade project to use `Java 21`
  
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  - ###
    ### ✅ Upgrade using Agent
    - [[View Log]](logs\6.1.upgradeProjectUsingAgent.log)
    
    - 27 files changed, 118 insertions(+), 438 deletions(-)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Code changes
    - Upgrade Java runtime to version 21 (LTS)
      - Updated maven.compiler.source from 17 to 21
      - Updated maven.compiler.target from 17 to 21
    </details>
  
    ### ✅ Build Project
    - [[View Log]](logs\6.2.buildProject.log)
    
    - Build result: 100% Java files compiled
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    </details>
  </details>

  ### ⏳ Validate & Fix ...Running
  
  
  - ###
    ### ✅ Validate CVEs
    - [[View Log]](logs\7.1.validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Checked Dependencies
      - java:*:21
    </details>
  
    ### ✅ Validate Code Behavior Changes
    - [[View Log]](logs\7.2.validateBehaviorChanges.log)
  
    ### ❗ Run Tests
    - [[View Log]](logs\7.3.runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Test result
    | Total | Passed | Failed | Skipped | Errors |
    |-------|--------|--------|---------|--------|
    | 3 | 2 | 1 | 0 | 0 |
    
    #### Errors
    - Expected condition failed: waiting for visibility of element located by By.cssSelector: input[inputmode='numeric'], input[name='pin'] (tried for 30 second(s) with 500 milliseconds interval)&#10;Build info: version: '4.18.1', revision: 'b1d3319b48'&#10;System info: os.name: 'Windows 11', os.arch: 'amd64', os.version: '10.0', java.version: '21.0.8'&#10;Driver info: org.openqa.selenium.chrome.ChromeDriver&#10;Capabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 144.0.7559.97, chrome: {chromedriverVersion: 144.0.7559.109 (6a8d5e49388..., userDataDir: C:\Users\gaytri\AppData\Loc...}, fedcm:accounts: true, goog:chromeOptions: {debuggerAddress: localhost:59489}, goog:processID: 46820, networkConnectionEnabled: false, pageLoadStrategy: normal, platformName: windows, proxy: Proxy(), se:cdp: ws://localhost:59489/devtoo..., se:cdpVersion: 144.0.7559.97, setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:extension:minPinLength: true, webauthn:extension:prf: true, webauthn:virtualAuthenticators: true}&#10;Session ID: 0035d697d758744ebd83de3a56f0ebe2
      ```
      org.openqa.selenium.TimeoutException: 
      Expected condition failed: waiting for visibility of element located by By.cssSelector: input[inputmode='numeric'], input[name='pin'] (tried for 30 second(s) with 500 milliseconds interval)
      Build info: version: '4.18.1', revision: 'b1d3319b48'
      System info: os.name: 'Windows 11', os.arch: 'amd64', os.version: '10.0', java.version: '21.0.8'
      Driver info: org.openqa.selenium.chrome.ChromeDriver
      Capabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 144.0.7559.97, chrome: {chromedriverVersion: 144.0.7559.109 (6a8d5e49388..., userDataDir: C:\Users\gaytri\AppData\Loc...}, fedcm:accounts: true, goog:chromeOptions: {debuggerAddress: localhost:59489}, goog:processID: 46820, networkConnectionEnabled: false, pageLoadStrategy: normal, platformName: windows, proxy: Proxy(), se:cdp: ws://localhost:59489/devtoo..., se:cdpVersion: 144.0.7559.97, setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:extension:minPinLength: true, webauthn:extension:prf: true, webauthn:virtualAuthenticators: true}
      Session ID: 0035d697d758744ebd83de3a56f0ebe2
      	at org.openqa.selenium.support.ui.WebDriverWait.timeoutException(WebDriverWait.java:84)
      	at org.openqa.selenium.support.ui.FluentWait.until(FluentWait.java:228)
      	at com.homeyhutz.base.BasePage.waitForVisibility(BasePage.java:21)
      	at com.homeyhutz.base.BasePage.type(BasePage.java:36)
      	at com.homeyhutz.pages.SignupPage.enterOtp(SignupPage.java:64)
      	at com.homeyhutz.tests.SignupFlowTest.signupFlowTest(SignupFlowTest.java:28)
      	at java.base/jdk.internal.reflect.DirectMethodHandleAccessor.invoke(DirectMethodHandleAccessor.java:103)
      	at java.base/java.lang.reflect.Method.invoke(Method.java:580)
      	at org.testng.internal.invokers.MethodInvocationHelper.invokeMethod(MethodInvocationHelper.java:139)
      	at org.testng.internal.invokers.TestInvoker.invokeMethod(TestInvoker.java:664)
      	at org.testng.internal.invokers.TestInvoker.invokeTestMethod(TestInvoker.java:228)
      	at org.testng.internal.invokers.MethodRunner.runInSequence(MethodRunner.java:63)
      	at org.testng.internal.invokers.TestInvoker$MethodInvocationAgent.invoke(TestInvoker.java:961)
      	at org.testng.internal.invokers.TestInvoker.invokeTestMethods(TestInvoker.java:201)
      	at org.testng.internal.invokers.TestMethodWorker.invokeTestMethods(TestMethodWorker.java:148)
      	at org.testng.internal.invokers.TestMethodWorker.run(TestMethodWorker.java:128)
      	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
      	at org.testng.TestRunner.privateRun(TestRunner.java:819)
      	at org.testng.TestRunner.run(TestRunner.java:619)
      	at org.testng.SuiteRunner.runTest(SuiteRunner.java:443)
      	at org.testng.SuiteRunner.runSequentially(SuiteRunner.java:437)
      	at org.testng.SuiteRunner.privateRun(SuiteRunner.java:397)
      	at org.testng.SuiteRunner.run(SuiteRunner.java:336)
      	at org.testng.SuiteRunnerWorker.runSuite(SuiteRunnerWorker.java:52)
      	at org.testng.SuiteRunnerWorker.run(SuiteRunnerWorker.java:95)
      	at org.testng.TestNG.runSuitesSequentially(TestNG.java:1301)
      	at org.testng.TestNG.runSuitesLocally(TestNG.java:1228)
      	at org.testng.TestNG.runSuites(TestNG.java:1134)
      	at org.testng.TestNG.run(TestNG.java:1101)
      	at org.apache.maven.surefire.testng.TestNGExecutor.run(TestNGExecutor.java:155)
      	at org.apache.maven.surefire.testng.TestNGDirectoryTestSuite.executeMulti(TestNGDirectoryTestSuite.java:169)
      	at org.apache.maven.surefire.testng.TestNGDirectoryTestSuite.execute(TestNGDirectoryTestSuite.java:88)
      	at org.apache.maven.surefire.testng.TestNGProvider.invoke(TestNGProvider.java:137)
      	at org.apache.maven.surefire.booter.ForkedBooter.runSuitesInProcess(ForkedBooter.java:385)
      	at org.apache.maven.surefire.booter.ForkedBooter.execute(ForkedBooter.java:162)
      	at org.apache.maven.surefire.booter.ForkedBooter.run(ForkedBooter.java:507)
      	at org.apache.maven.surefire.booter.ForkedBooter.main(ForkedBooter.java:495)
      
      ```
    </details>
  
    ### ✅ Fix Test Errors/Failures
    - [[View Log]](logs\7.4.fixTestErrors.log)
    
    - 35 files changed, 0 insertions(+), 1868 deletions(-)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Code changes
    - No additional code changes made
    </details>
  
    ### ✅ Build Project
    - [[View Log]](logs\7.5.buildProject.log)
    
    - Build result: 100% Java files compiled
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    </details>
  
    ### ✅ Validate CVEs
    - [[View Log]](logs\7.6.validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Checked Dependencies
      - java:*:21
    </details>
  
    ### ✅ Validate Code Behavior Changes
    - [[View Log]](logs\7.7.validateBehaviorChanges.log)
  
    ### ❗ Run Tests
    - [[View Log]](logs\7.8.runTests.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Test result
    | Total | Passed | Failed | Skipped | Errors |
    |-------|--------|--------|---------|--------|
    | 3 | 2 | 1 | 0 | 0 |
    
    #### Errors
    - Expected condition failed: waiting for visibility of element located by By.cssSelector: input[inputmode='numeric'], input[name='pin'] (tried for 30 second(s) with 500 milliseconds interval)&#10;Build info: version: '4.18.1', revision: 'b1d3319b48'&#10;System info: os.name: 'Windows 11', os.arch: 'amd64', os.version: '10.0', java.version: '21.0.8'&#10;Driver info: org.openqa.selenium.chrome.ChromeDriver&#10;Capabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 144.0.7559.97, chrome: {chromedriverVersion: 144.0.7559.109 (6a8d5e49388..., userDataDir: C:\Users\gaytri\AppData\Loc...}, fedcm:accounts: true, goog:chromeOptions: {debuggerAddress: localhost:64190}, goog:processID: 54104, networkConnectionEnabled: false, pageLoadStrategy: normal, platformName: windows, proxy: Proxy(), se:cdp: ws://localhost:64190/devtoo..., se:cdpVersion: 144.0.7559.97, setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:extension:minPinLength: true, webauthn:extension:prf: true, webauthn:virtualAuthenticators: true}&#10;Session ID: 0150d9c3f68d1f2acace82efeb6e839d
      ```
      org.openqa.selenium.TimeoutException: 
      Expected condition failed: waiting for visibility of element located by By.cssSelector: input[inputmode='numeric'], input[name='pin'] (tried for 30 second(s) with 500 milliseconds interval)
      Build info: version: '4.18.1', revision: 'b1d3319b48'
      System info: os.name: 'Windows 11', os.arch: 'amd64', os.version: '10.0', java.version: '21.0.8'
      Driver info: org.openqa.selenium.chrome.ChromeDriver
      Capabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 144.0.7559.97, chrome: {chromedriverVersion: 144.0.7559.109 (6a8d5e49388..., userDataDir: C:\Users\gaytri\AppData\Loc...}, fedcm:accounts: true, goog:chromeOptions: {debuggerAddress: localhost:64190}, goog:processID: 54104, networkConnectionEnabled: false, pageLoadStrategy: normal, platformName: windows, proxy: Proxy(), se:cdp: ws://localhost:64190/devtoo..., se:cdpVersion: 144.0.7559.97, setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:extension:credBlob: true, webauthn:extension:largeBlob: true, webauthn:extension:minPinLength: true, webauthn:extension:prf: true, webauthn:virtualAuthenticators: true}
      Session ID: 0150d9c3f68d1f2acace82efeb6e839d
      	at org.openqa.selenium.support.ui.WebDriverWait.timeoutException(WebDriverWait.java:84)
      	at org.openqa.selenium.support.ui.FluentWait.until(FluentWait.java:228)
      	at com.homeyhutz.base.BasePage.waitForVisibility(BasePage.java:21)
      	at com.homeyhutz.base.BasePage.type(BasePage.java:36)
      	at com.homeyhutz.pages.SignupPage.enterOtp(SignupPage.java:64)
      	at com.homeyhutz.tests.SignupFlowTest.signupFlowTest(SignupFlowTest.java:28)
      	at java.base/jdk.internal.reflect.DirectMethodHandleAccessor.invoke(DirectMethodHandleAccessor.java:103)
      	at java.base/java.lang.reflect.Method.invoke(Method.java:580)
      	at org.testng.internal.invokers.MethodInvocationHelper.invokeMethod(MethodInvocationHelper.java:139)
      	at org.testng.internal.invokers.TestInvoker.invokeMethod(TestInvoker.java:664)
      	at org.testng.internal.invokers.TestInvoker.invokeTestMethod(TestInvoker.java:228)
      	at org.testng.internal.invokers.MethodRunner.runInSequence(MethodRunner.java:63)
      	at org.testng.internal.invokers.TestInvoker$MethodInvocationAgent.invoke(TestInvoker.java:961)
      	at org.testng.internal.invokers.TestInvoker.invokeTestMethods(TestInvoker.java:201)
      	at org.testng.internal.invokers.TestMethodWorker.invokeTestMethods(TestMethodWorker.java:148)
      	at org.testng.internal.invokers.TestMethodWorker.run(TestMethodWorker.java:128)
      	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
      	at org.testng.TestRunner.privateRun(TestRunner.java:819)
      	at org.testng.TestRunner.run(TestRunner.java:619)
      	at org.testng.SuiteRunner.runTest(SuiteRunner.java:443)
      	at org.testng.SuiteRunner.runSequentially(SuiteRunner.java:437)
      	at org.testng.SuiteRunner.privateRun(SuiteRunner.java:397)
      	at org.testng.SuiteRunner.run(SuiteRunner.java:336)
      	at org.testng.SuiteRunnerWorker.runSuite(SuiteRunnerWorker.java:52)
      	at org.testng.SuiteRunnerWorker.run(SuiteRunnerWorker.java:95)
      	at org.testng.TestNG.runSuitesSequentially(TestNG.java:1301)
      	at org.testng.TestNG.runSuitesLocally(TestNG.java:1228)
      	at org.testng.TestNG.runSuites(TestNG.java:1134)
      	at org.testng.TestNG.run(TestNG.java:1101)
      	at org.apache.maven.surefire.testng.TestNGExecutor.run(TestNGExecutor.java:155)
      	at org.apache.maven.surefire.testng.TestNGDirectoryTestSuite.executeMulti(TestNGDirectoryTestSuite.java:169)
      	at org.apache.maven.surefire.testng.TestNGDirectoryTestSuite.execute(TestNGDirectoryTestSuite.java:88)
      	at org.apache.maven.surefire.testng.TestNGProvider.invoke(TestNGProvider.java:137)
      	at org.apache.maven.surefire.booter.ForkedBooter.runSuitesInProcess(ForkedBooter.java:385)
      	at org.apache.maven.surefire.booter.ForkedBooter.execute(ForkedBooter.java:162)
      	at org.apache.maven.surefire.booter.ForkedBooter.run(ForkedBooter.java:507)
      	at org.apache.maven.surefire.booter.ForkedBooter.main(ForkedBooter.java:495)
      
      ```
    </details>
  
    ### ✅ Fix Test Errors/Failures
    - [[View Log]](logs\7.9.fixTestErrors.log)
    
    - 38 files changed, 1876 insertions(+), 1 deletion(-)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Code changes
    - Update Selenium dependency to address Chrome CDP warnings
      - Upgraded selenium-java from 4.18.1 to 4.28.0 for Chrome 144 CDP support
    - Add SLF4J logger implementation
      - Added slf4j-simple 2.0.16 to eliminate SLF4J warnings
    </details>
  
    ### ✅ Build Project
    - [[View Log]](logs\7.10.buildProject.log)
    
    - Build result: 100% Java files compiled
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Command
    `mvn clean test-compile -q -B -fn`
    </details>
  
    ### ✅ Validate CVEs
    - [[View Log]](logs\7.11.validateCves.log)
    
    <details>
        <summary>[ click to toggle details ]</summary>
    
    #### Checked Dependencies
      - org.slf4j:slf4j-simple:2.0.16:jar
      - org.seleniumhq.selenium:selenium-java:4.28.0:jar
      - java:*:21
    </details>
  
    ### ✅ Validate Code Behavior Changes
    - [[View Log]](logs\7.12.validateBehaviorChanges.log)